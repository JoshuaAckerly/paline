@echo off
cd /d "%~dp0"
echo Starting PA LINE Booking Platform...
node scripts\dev-server.mjs
pause
