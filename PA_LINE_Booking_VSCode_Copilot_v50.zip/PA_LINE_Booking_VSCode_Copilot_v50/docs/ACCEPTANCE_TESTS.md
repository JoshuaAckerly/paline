# Core Acceptance Tests

Run these after significant Copilot changes.

1. Landing page shows all three primary booking paths plus BACK FOR MORE.
2. Exact date remains selected unless the user deliberately selects another date.
3. Available, Limited, Held, and Blocked states remain distinct.
4. Limited-date logic preserves 2 hours before and 2 hours after each performance plus travel.
5. Performance start before 10:00 AM fails.
6. Performance start after 11:00 PM fails.
7. Two Goats Brewing fills 5027 State Route 414, Burdett, NY 14818.
8. Manual text input is not overwritten by stale predictive results.
9. Travel routing uses surrounding confirmed gigs and falls back to 360 Gould Avenue, Depew, NY 14043.
10. Mileage uses $0.80/mile.
11. Extra base-rate travel allowance applies only when combined inbound + outbound drive exceeds 8 hours.
12. Working budget is optional.
13. A budget above the internal requirement does not reveal the lower internal requirement.
14. A budget below the requirement offers date/season, Duo/Solo, or manual budget review.
15. Manual budget review can reach final review with no priced performance quote.
16. Final standard price is itemized.
17. TRUE POTENTIAL remains custom quote.
18. Confidential pricing remains gated by verified-account simulation + NDA acceptance.
19. Legal document checkboxes remain disabled until the active document version is opened and scrolled to the bottom.
20. Updating an active legal document relocks its acknowledgment.
21. Updating the NDA invalidates previous confidentiality acceptance.
22. Confirmed travel price acts as a ceiling.
23. Later route savings are incremental and cannot be double-credited.
24. Route Savings default favors the booker.
25. Route Builder Credit is used only for documented referrals that produce a confirmed route-improving show.
26. Standard final submit button repeats the final total.
27. Booking submission remains a request until PA LINE approval.
