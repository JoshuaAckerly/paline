# Safe Refactor Plan

Do not rewrite the application in one jump. Preserve the working v49/v50 behavior while gradually improving structure.

## Stage 0: baseline

Before changing architecture:

```bash
npm install
npm run validate
npm run dev
```

Manually verify the four landing paths and final Review & Sign flow.

## Stage 1: remove inline HTML event handlers

The current app relies on attributes such as `onclick`, `oninput`, and `onchange`.

Replace them screen-by-screen with `addEventListener` registrations in JavaScript.

Do not change behavior during this stage.

Once all inline handlers are gone, the application can safely move toward ES modules.

## Stage 2: add automated browser tests

Recommended first end-to-end tests:

1. exact-date flow,
2. flexible-date flow,
3. working budget above required amount,
4. working budget below required amount -> Duo/Solo alternatives,
5. manual budget review with no priced quote,
6. legal document scroll-to-unlock,
7. final itemization,
8. Route Savings Choice,
9. Two Goats venue autofill -> Burdett, NY 14818.

Playwright is a good fit once the project is stable under Vite.

## Stage 3: domain modules

Move pure business logic into modules without UI dependencies:

```text
src/domain/
  pricing.js
  routing.js
  availability.js
  recurrence.js
  budget.js
  route-savings.js
  legal.js
```

Unit-test every business rule.

## Stage 4: UI modules

Split page behavior:

```text
src/ui/
  navigation.js
  calendar.js
  autocomplete.js
  budget.js
  legal-review.js
  final-review.js
  returning-booker.js
```

## Stage 5: real backend

Replace browser-only simulations with server APIs for:

- magic-link authentication,
- user/venue authorization,
- live PA LINE calendar,
- road routing/mileage,
- pricing snapshots,
- legal versions and acceptance audits,
- booking submissions,
- Route Savings settlements,
- payments/refunds when policies are finalized.

## Stage 6: optional framework migration

Only after business logic is tested and event handlers are no longer inline should you decide whether React/Next.js adds enough value.

Do not migrate frameworks simply because Copilot suggests it.
