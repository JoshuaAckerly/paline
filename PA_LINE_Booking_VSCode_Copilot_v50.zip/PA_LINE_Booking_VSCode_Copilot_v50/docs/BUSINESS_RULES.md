# PA LINE Booking Business Rules

This file is a compact human-readable source of truth for development.

## Home routing origin/destination

When there is no surrounding confirmed engagement, use:

**360 Gould Avenue, Depew, NY 14043**

## Travel

- Route from previous confirmed engagement/home to requested venue, then requested venue to next confirmed engagement/home.
- $0.80 per routed mile.
- Add one extra season-adjusted base performance rate only if combined inbound + outbound driving exceeds 8 hours.
- Exactly 8 hours or less gets no extra base-rate travel allowance.

## Show-day buffers

Every show reserves:

`2 hours before + performance duration + 2 hours after + travel between engagements`

Start-time range:

`10:00 AM through 11:00 PM`

## Route savings

Confirmed travel charge is a ceiling. Later route improvement can reduce it, never increase it because of a later PA LINE routing change.

Incremental realized savings belong to the affected booking.

Booker can choose:

- return/apply to balance,
- future booking credit,
- voluntary PA LINE touring/promotional reinvestment,
- 50/50,
- custom 100% allocation.

Default without a choice benefits the buyer.

## Working budget

Budget is optional.

If budget supports requested configuration:

- do not reveal an internal lower floor,
- offer a negotiated package within the supplied budget,
- show itemization only at final review.

If budget does not support requested configuration:

- suggest route/season/date changes,
- suggest Duo or Solo where appropriate,
- allow no-price manual budget review.

## Final itemization

Standard booking final screen itemizes applicable:

1. performance fee,
2. routed mileage,
3. over-8-hour allowance,
4. PA LINE sound,
5. sound-tech labor,
6. sound-tech mileage,
7. exclusivity,
8. merch,
9. final request total.

## Legal

Only active legal versions may be acknowledged.

A changed legal version must be reviewed again. Buyers must open and scroll each required document to the bottom before its checkbox becomes enabled.

## Repeat eligibility

4+ qualifying gigs/year based on either venue or authorized booking person.

Actual discount values remain intentionally undefined.
