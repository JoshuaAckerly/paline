# Copilot Context

## What this codebase is

This is the approved PA LINE booking prototype migrated into a maintainable VS Code project without changing the core browser behavior.

The project currently uses:

- static HTML,
- CSS,
- classic browser JavaScript,
- browser localStorage for prototype memory/admin legal overrides,
- simulated route/calendar/auth integrations in some areas.

## Current entry paths

1. I KNOW MY DATE
2. HELP ME FIND THE SWEET SPOT
3. GET OVER HERE
4. BACK FOR MORE? returning booker

All commercial booking paths converge on secure pricing, legal review, final itemization, and submission.

## Important product systems already present

- custom date picker,
- Available / Limited / Held / Blocked calendar states,
- same-day booking windows,
- format selection: Solo / Duo / Full PA LINE,
- TRUE POTENTIAL custom production,
- sound and sound-tech pricing,
- recurring/multi-date request UI,
- confidentiality gate,
- legal-document scroll-to-unlock review,
- working-budget fit logic,
- final itemized price,
- route price protection,
- Route Savings Choice / Route Builder Credit,
- booking-only merch bundles,
- predictive venue/event/contact/location entry,
- returning-booker portal,
- legal-document admin demo.

## Maintainability reality

`src/app.js` is still large. That is intentional for the first migration because the approved prototype used many inline event attributes.

The next refactor should be behavior-preserving and test-first. See `SAFE_REFACTOR_PLAN.md`.
