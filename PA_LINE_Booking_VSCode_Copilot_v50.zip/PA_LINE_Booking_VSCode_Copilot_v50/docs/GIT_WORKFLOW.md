# Recommended Git workflow

Before letting Copilot make large edits, put the project under Git version control.

From the VS Code terminal:

```bash
git init
git add .
git commit -m "Baseline PA LINE booking migration v50"
```

Then create a new branch for larger work:

```bash
git checkout -b copilot-refactor
```

After every safe milestone:

```bash
npm run validate
git add .
git commit -m "Describe the completed change"
```

This gives you an easy way to undo a bad Copilot change without losing the working baseline.
