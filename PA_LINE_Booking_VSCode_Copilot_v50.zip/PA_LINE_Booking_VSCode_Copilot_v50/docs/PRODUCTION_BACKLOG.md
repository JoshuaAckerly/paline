# Production Backlog

The current VS Code project is a working interactive prototype. These items are required for production deployment.

## P0: security / source of truth

- Real passwordless authentication.
- Server-side authorization by user, organization, and venue.
- Database-backed booking drafts and confirmed bookings.
- Live authoritative PA LINE calendar.
- Real routing provider and geocoding.
- Server-side price recalculation before submission.
- Immutable legal document/version storage.
- Legal acceptance audit records.

## P1: booking operations

- PA LINE admin booking inbox.
- Holds and confirmations.
- Quote approval/override.
- Multi-date pricing for every date in a series.
- Route Savings Event + Election accounting.
- Transactional email notifications.

## P2: financial operations

Do not implement until policies are finalized:

- deposits,
- balance timing,
- payment processor,
- refund method,
- cancellation amounts,
- discount amounts/stacking,
- Venue Appreciation Credit economics.

## P3: product polish

- Full accessibility audit.
- Automated browser tests.
- Mobile/device QA.
- Observability/error logging.
- Admin venue/contact cleanup tools.
