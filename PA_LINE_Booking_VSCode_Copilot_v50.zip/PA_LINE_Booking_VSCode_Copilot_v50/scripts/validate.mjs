import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const htmlPath = path.join(root, 'index.html');
const jsPath = path.join(root, 'src', 'app.js');

const html = fs.readFileSync(htmlPath, 'utf8');
const js = fs.readFileSync(jsPath, 'utf8');
const failures = [];

const syntax = spawnSync(process.execPath, ['--check', jsPath], { encoding: 'utf8' });
if (syntax.status !== 0) failures.push(`JavaScript syntax failure:\n${syntax.stderr}`);

const idMatches = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
const idSet = new Set(idMatches);
const duplicateIds = [...new Set(idMatches.filter((id, i) => idMatches.indexOf(id) !== i))];
if (duplicateIds.length) failures.push(`Duplicate HTML IDs: ${duplicateIds.join(', ')}`);

const referencedIds = [...js.matchAll(/\$\("([^"]+)"\)/g)].map(m => m[1]);
const missingIds = [...new Set(referencedIds.filter(id => !idSet.has(id)))];
if (missingIds.length) failures.push(`Missing DOM IDs referenced by $(): ${missingIds.join(', ')}`);

const requiredMarkers = [
  ['PA LINE brand', 'PA LINE'],
  ['home routing address', '360 Gould Avenue, Depew, NY 14043'],
  ['budget field', 'id="bookerBudget"'],
  ['manual budget review', 'acceptManualBudgetReview'],
  ['Route Savings page', 'id="pageRouteSavings"'],
  ['final itemization mileage', 'Routed mileage'],
  ['legal admin page', 'id="pageLegalAdmin"'],
  ['legal scroll gate', 'completeDocumentReview'],
  ['Two Goats verified venue', '5027 State Route 414'],
  ['Burdett venue city', 'city:"Burdett"'],
  ['11 PM scheduling boundary', '23*60'],
  ['10 AM scheduling boundary', '10*60'],
  ['mileage rate', 'MILEAGE_RATE=0.80'],
  ['8-hour travel threshold', 'MAX_DRIVE_HOURS_PER_DAY=8'],
];

const combined = `${html}\n${js}`;
for (const [label, marker] of requiredMarkers) {
  if (!combined.includes(marker)) failures.push(`Missing critical marker: ${label} (${marker})`);
}

if (failures.length) {
  console.error('\nPA LINE validation FAILED\n');
  failures.forEach((f, i) => console.error(`${i + 1}. ${f}`));
  process.exit(1);
}

console.log('PA LINE validation PASS');
console.log(`HTML IDs: ${idSet.size}`);
console.log(`$() DOM references checked: ${new Set(referencedIds).size}`);
console.log('Critical business-rule markers: present');
