# Legal source files

These files are included as editable/reference source material for the PA LINE booking system.

The browser application currently contains bundled review templates in `index.html` and also supports active admin overrides through the LEGAL DOCS manager.

For production, migrate these documents into an authenticated, versioned legal-document service. Never overwrite a document version that has already been accepted by a booker. Create a new version instead and preserve the exact accepted version on the booking record.

Current files:

- Performance_Agreement_v49.docx
- Stage_Plot.html
- Technical_Rider.html
- Personal_Hospitality_Rider.html

Attorney review is recommended before production deployment.
