# GitHub Copilot instructions for the PA LINE Booking Platform

Read this file before proposing or applying changes.

## Product identity

- Always write the artist name as **PA LINE**.
- Do not use em dashes in user-facing copy.
- This is a booking assistant, not a generic contact form.
- Do not remove business behavior merely because it appears unusual.

## Migration rule

The current v50 code is a behavior-preserving bridge from the approved v49 prototype.

Before any large refactor:

1. run `npm run validate`,
2. preserve the relevant business rule,
3. make the smallest safe change,
4. run validation again,
5. test the user flow in the browser.

Do not convert `src/app.js` to an ES module until all inline HTML event handlers have either been replaced or explicitly exported to `window`.

## Scheduling rules that must not regress

- Earliest PA LINE performance start: **10:00 AM**.
- Latest PA LINE performance start: **11:00 PM**.
- Every show reserves **2 hours before + performance duration + 2 hours after**.
- Travel time between engagements is additional to those buffers.
- A booked date may remain **Limited** if a safe second show can fit.
- The selected exact date stays selected unless the user explicitly chooses an alternate.

## Travel pricing

Routing basis for a booking is:

`previous confirmed gig -> requested venue -> next confirmed gig`

If no previous confirmed gig exists, use:

`360 Gould Avenue, Depew, NY 14043`

If no next confirmed gig exists, use the same home address.

- Mileage rate: **$0.80/mile** across the routed legs.
- Add **one additional season-adjusted base performance rate only when combined inbound + outbound driving exceeds 8 hours**.
- Exactly 8 hours or less does not receive the extra base-rate allowance.
- Do not invent an hourly drive-time fee.

## Route price protection and Route Savings

When a booking confirms, its travel component becomes a **ceiling**.

Later confirmed route improvements may reduce that travel charge, but PA LINE changing the surrounding route later must not increase an already-confirmed venue's protected travel charge.

When a later confirmed show creates real incremental savings for an earlier booking:

- create Route Reoptimization Savings,
- if the route-improving confirmed show came through that booker/venue's documented recommendation, label it **ROUTE BUILDER CREDIT**,
- do not double-credit the same savings,
- do not claw back already granted savings simply because the route becomes worse later.

The affected booker controls the savings:

- return/apply to unpaid balance,
- future booking credit,
- voluntarily reinvest with PA LINE,
- 50/50 split,
- custom split totaling 100%.

No response defaults in the booker's favor: apply savings to unpaid balance, then treat any remainder as due back.

PA LINE Music, LLC is a for-profit business. Voluntary reinvestment must not be described as a charitable or tax-deductible donation.

## Pricing and working budget

The buyer may optionally enter a working **performance budget** before final review.

The working performance budget covers the core PA LINE performance package, including performance, routing/travel, sound, and production. Optional merch and requested exclusivity are separate.

If the stated budget is at or above the internal required package calculation:

- treat the booking as workable within the stated budget,
- do not reveal the lower internal required amount,
- the offered negotiated core package may be presented at the stated budget,
- itemize the offered price only at the final Review & Sign step.

If the budget is below the required configuration:

- offer a different date/season,
- offer Duo when appropriate,
- offer Solo when appropriate,
- allow the buyer to keep the requested configuration and submit for **manual budget review without a priced performance quote**.

If manual budget review is chosen, clearly tell the buyer that PA LINE wants to work within their limitations and parameters and will review the request before issuing a firm price.

Do not fabricate a price merely to force the flow to completion.

## Final price

For standard priced bookings, the authoritative price appears at the final **Review & Sign** step and is itemized.

Keep distinct line items for applicable:

- performance fee,
- routed mileage,
- extended-travel allowance,
- PA LINE sound package,
- dedicated sound-technician labor,
- sound-technician mileage,
- exclusivity,
- booking-only merch,
- final request total.

TRUE POTENTIAL remains **CUSTOM QUOTE**.

Manual budget-review requests remain **NO PRICED PERFORMANCE QUOTE ATTACHED** until PA LINE issues an offer.

## Baseline performance rates

Solo:
- Sun/Mon/Tue: $200
- Wed/Thu: $250
- Fri/Sat: $300

Duo:
- Sun/Mon/Tue: $350
- Wed/Thu: $450
- Fri/Sat: $550

Full PA LINE:
- Sun/Mon/Tue: $600
- Wed/Thu: $750
- Fri/Sat: $1,000

Season multipliers:
- Dec/Jan/Feb: 0.75
- Mar/Apr/Oct/Nov: 1.00
- May/Sep: 1.25
- Jun/Jul/Aug: 1.40

## Sound rules

When PA LINE supplies sound:
- Solo: +$25
- Duo: +$50
- Full PA LINE: +$250

Dedicated PA LINE sound tech:
- $150 base fee
- $0.80/mile when applicable

## Legal-document rules

Legal documents must remain updateable by an authorized PA LINE administrator.

Current document types:

- Confidential Pricing Agreement / NDA,
- Performance Agreement,
- Stage Plot,
- Technical Rider,
- Personal / Hospitality Rider.

Changing an active document version invalidates the prior review state for that document. Changing the NDA invalidates prior confidentiality acceptance.

A buyer cannot acknowledge a document until they open it and scroll to the bottom. The checkbox starts disabled and only unlocks after the active version is reviewed to the end.

Production must store immutable legal-document versions and the exact version accepted for each booking.

## Private pricing and authentication

Do not expose individualized private pricing, prior negotiated terms, or confidential booking history before verified account access and confidentiality acceptance.

Production should use passwordless email magic links plus server-side authorization.

## Repeat and discount rules

Repeat-booking eligibility begins at **4+ qualifying gigs per year** by venue or authorized booking person.

Do not invent discount percentages, stacking rules, referral payouts, or Venue Appreciation Credit economics unless Trever explicitly defines them.

## Predictive text

Manual typing always wins.

- Suggestions are passive until selected.
- Ignore stale async search results.
- Programmatic autofill must not recursively trigger more autofill.
- Enter alone must not choose the first suggestion.
- Arrow-key navigation + Enter may choose a highlighted suggestion.
- Remote venue/place data may fill missing fields but must not overwrite trusted known venue city/state/ZIP/address data.

Known verified example:

Two Goats Brewing
5027 State Route 414
Burdett, NY 14818

## Prototype limitations

Do not describe simulated behavior as production-live. Current simulated areas include routing, email magic links, backend authorization, payments, and some calendar behavior.

When replacing simulations, preserve the product rules above and move critical validation/pricing to the server.
